using Microsoft.EntityFrameworkCore;
using WebAppArchitecture.Base.Security;
using WebAppArchitecture.Group.Models;
using WebAppArchitecture.Role.Models;
using WebAppArchitecture.RoleType.Models;
using WebAppArchitecture.User.Models;

namespace WebAppArchitecture.Persistence;

public static class DatabaseInitializer
{
    public static async Task InitializeAsync(ApplicationDbContext db, CancellationToken cancellationToken = default)
    {
        await db.Database.EnsureCreatedAsync(cancellationToken);
        var now = DateTimeOffset.UtcNow;

        if (!await db.GroupTypes.AnyAsync(x => x.id == RbacWellKnown.RootGroupTypeId, cancellationToken))
        {
            db.GroupTypes.Add(new GroupTypeModel(
                RbacWellKnown.RootGroupTypeId,
                "Root group type",
                null,
                $"/{RbacWellKnown.RootGroupTypeId:D}/",
                RbacWellKnown.RootGroupId,
                now, now, RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
        }

        if (!await db.Groups.AnyAsync(x => x.id == RbacWellKnown.RootGroupId, cancellationToken))
        {
            db.Groups.Add(new GroupModel(
                RbacWellKnown.RootGroupId,
                "Root",
                RbacWellKnown.RootGroupTypeId,
                null,
                $"/{RbacWellKnown.RootGroupId:D}/",
                RbacWellKnown.RootGroupId,
                now, now, RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
        }

        foreach (var seed in FakeEntraSeedUsers.All.Append(new FakeEntraSeedUser(
                     RbacWellKnown.BootstrapAdminUserId, "Bootstrap Admin", "bootstrap@local", "Administrator")))
        {
            if (!await db.Users.AnyAsync(x => x.id == seed.id, cancellationToken))
            {
                db.Users.Add(new UserModel(seed.id, seed.Name, RbacWellKnown.RootGroupId, now, now,
                    RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
            }
        }

        var allOperations = new[]
        {
            RbacOperations.Create, RbacOperations.Read, RbacOperations.Update, RbacOperations.Delete,
            RbacOperations.List, RbacOperations.Vector, RbacOperations.ManageGroups,
            RbacOperations.ManageMemberships, RbacOperations.ManageRoles, RbacOperations.ManageSecurityObjects
        };

        foreach (var roleName in new[] { "Administrator", "Rector", "Dean" })
        {
            if (!await db.RoleTypes.AnyAsync(x => x.name == roleName, cancellationToken))
            {
                db.RoleTypes.Add(new RoleTypeModel(Guid.NewGuid(), roleName, string.Join(',', allOperations),
                    RbacWellKnown.RootGroupId, now, now, RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
            }
        }

        await db.SaveChangesAsync(cancellationToken);

        foreach (var seed in FakeEntraSeedUsers.All.Append(new FakeEntraSeedUser(
                     RbacWellKnown.BootstrapAdminUserId, "Bootstrap Admin", "bootstrap@local", "Administrator")))
        {
            if (!await db.Roles.AnyAsync(x => x.user_id == seed.id && x.group_id == RbacWellKnown.RootGroupId && x.role_type == seed.RootRoleType, cancellationToken))
            {
                db.Roles.Add(new RoleModel(Guid.NewGuid(), RbacWellKnown.RootGroupId, seed.id, seed.RootRoleType,
                    false, now.AddYears(-1), null, null, RbacWellKnown.RootGroupId, now, now,
                    RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
            }
        }

        await db.SaveChangesAsync(cancellationToken);
    }
}
