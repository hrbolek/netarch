using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace WebAppArchitecture.Base.Security;

/// <summary>
/// Persistence contract dedicated to authorization queries. It intentionally
/// exposes authorization facts, not IQueryable/DbContext, to the Service layer.
/// </summary>
public interface ISecurityStore
{
    Task<IReadOnlySet<string>> GetAllowedOperationsAsync(
        Guid userId,
        Guid rbacId,
        DateTimeOffset at,
        CancellationToken cancellationToken = default);

    Task<bool> HasAssignableRoleAsync(
        Guid userId,
        Guid groupId,
        string roleType,
        DateTimeOffset validFrom,
        DateTimeOffset? validTo,
        CancellationToken cancellationToken = default);
}

public interface ISecurityService : IRbacService
{
    Task<IReadOnlySet<string>> GetAllowedOperationsAsync(
        Guid userId,
        Guid rbacId,
        CancellationToken cancellationToken = default);
}

/// <summary>
/// Application-level authorization service. All hierarchy/persistence details
/// stay behind ISecurityStore.
/// </summary>
public sealed class SecurityService : ISecurityService
{
    private readonly ISecurityStore _store;
    private readonly ICurrentActorProvider _actorProvider;

    public SecurityService(ISecurityStore store, ICurrentActorProvider actorProvider)
    {
        _store = store;
        _actorProvider = actorProvider;
    }

    public Task<IReadOnlySet<string>> GetAllowedOperationsAsync(Guid userId, Guid rbacId, CancellationToken cancellationToken = default)
        => _store.GetAllowedOperationsAsync(userId, rbacId, DateTimeOffset.UtcNow, cancellationToken);

    public async Task<bool> IsAllowedAsync(Guid actorUserId, Guid rbacObjectId, string operation, CancellationToken cancellationToken = default)
    {
        if (actorUserId == Guid.Empty || string.IsNullOrWhiteSpace(operation))
            return false;

        var operations = await GetAllowedOperationsAsync(actorUserId, rbacObjectId, cancellationToken);
        return operations.Contains(operation.Trim().ToLowerInvariant());
    }

    public async Task<bool> IsCurrentActorAllowedAsync(HttpContext httpContext, Guid rbacObjectId, string operation, CancellationToken cancellationToken = default)
    {
        var userId = _actorProvider.TryGetActorUserId(httpContext);
        return userId is not null && await IsAllowedAsync(userId.Value, rbacObjectId, operation, cancellationToken);
    }

    public Task<bool> CanAssignDeputyRoleAsync(Guid actorUserId, Guid groupId, string roleType, DateTimeOffset validFrom, DateTimeOffset? validTo, CancellationToken cancellationToken = default)
        => _store.HasAssignableRoleAsync(actorUserId, groupId, roleType.Trim(), validFrom, validTo, cancellationToken);
}

public static class SecurityEndpointExtensions
{
    public static IEndpointRouteBuilder MapSecurityEndpoints(this IEndpointRouteBuilder endpoints, string prefix)
    {
        var group = endpoints.MapGroup(prefix.TrimEnd('/') + "/security").WithTags("Security");

        group.MapGet("/{rbacId:guid}/operations", async (
            Guid rbacId,
            Guid? userId,
            HttpContext httpContext,
            ISecurityService service,
            ICurrentActorProvider actorProvider,
            CancellationToken cancellationToken) =>
        {
            var effectiveUserId = userId ?? actorProvider.TryGetActorUserId(httpContext);
            if (effectiveUserId is null)
                return Results.Unauthorized();

            var operations = await service.GetAllowedOperationsAsync(effectiveUserId.Value, rbacId, cancellationToken);
            return Results.Ok(operations.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToArray());
        })
        .WithName("SecurityAllowedOperations")
        .Produces<string[]>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status401Unauthorized);

        return endpoints;
    }
}
