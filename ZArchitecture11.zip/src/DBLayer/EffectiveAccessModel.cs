using WebAppArchitecture.Base.Data;

namespace WebAppArchitecture.DBLayer;

/// <summary>
/// Materialized authorization projection. It is derived data, not the source of truth.
/// </summary>
public sealed record EffectiveAccessModel(
    Guid user_id,
    Guid rbac_id,
    string role_type,
    Guid source_role_id,
    Guid source_group_id,
    DateTimeOffset valid_from,
    DateTimeOffset? valid_to
) : IEntityDBModel
{
    // Required only by the generic persistence contract. EffectiveAccess uses a composite EF key.
    public Guid id => source_role_id;
}
