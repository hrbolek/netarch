using System.Linq.Expressions;
using WebAppArchitecture.Base.Data;
using WebAppArchitecture.Base.Security;
using WebAppArchitecture.RoleType.Models;

namespace WebAppArchitecture.Role.Models;

public sealed record RoleModel(
    Guid id,
    Guid group_id,
    Guid user_id,
    Guid role_type_id,
    bool is_deputy,
    DateTimeOffset valid_from,
    DateTimeOffset? valid_to,
    Guid? delegated_by_role_id,
    Guid rbac_id,
    DateTimeOffset created_at,
    DateTimeOffset updated_at,
    Guid created_by,
    Guid updated_by,
    string? group_name = null,
    string? user_name = null
) : ISecuredEntityDBModel
{
    public RoleTypeModel? role_type { get; init; }
}

public sealed record RoleResponse(
    Guid id,
    Guid group_id,
    Guid user_id,
    Guid role_type_id,
    string? role_type,
    bool is_deputy,
    DateTimeOffset valid_from,
    DateTimeOffset? valid_to,
    Guid? delegated_by_role_id,
    Guid rbac_id,
    DateTimeOffset created_at,
    DateTimeOffset updated_at,
    Guid created_by,
    Guid updated_by,
    string? group_name = null,
    string? user_name = null,
    string? delegated_by_role_type = null
) : IEntityDTOModel<RoleModel, RoleResponse>, ISecuredEntityDTOModel
{
    public static RoleResponse FromModel(RoleModel model) => new(
        model.id, model.group_id, model.user_id, model.role_type_id, model.role_type?.name,
        model.is_deputy, model.valid_from, model.valid_to, model.delegated_by_role_id,
        model.rbac_id, model.created_at, model.updated_at, model.created_by, model.updated_by,
        model.group_name, model.user_name, null);

    public static Expression<Func<RoleModel, RoleResponse>> Projection => model => new RoleResponse(
        model.id, model.group_id, model.user_id, model.role_type_id, model.role_type != null ? model.role_type.name : null,
        model.is_deputy, model.valid_from, model.valid_to, model.delegated_by_role_id,
        model.rbac_id, model.created_at, model.updated_at, model.created_by, model.updated_by,
        model.group_name, model.user_name, null);

    public RoleModel ToModel() => new(id, group_id, user_id, role_type_id, is_deputy, valid_from, valid_to,
        delegated_by_role_id, rbac_id, created_at, updated_at, created_by, updated_by, group_name, user_name);
}

public sealed record RoleCreateRequest(
    Guid group_id,
    Guid user_id,
    Guid role_type_id,
    bool is_deputy,
    DateTimeOffset valid_from,
    DateTimeOffset? valid_to = null,
    Guid? delegated_by_role_id = null,
    Guid? rbac_id = null,
    DateTimeOffset? created_at = null,
    DateTimeOffset? updated_at = null,
    Guid? created_by = null,
    Guid? updated_by = null
) : ICreateDTOModel<RoleModel>, ISecuredCreateRequest
{
    public RoleModel ToModel()
    {
        var now = DateTimeOffset.UtcNow;
        return new(Guid.NewGuid(), group_id, user_id, role_type_id, is_deputy, valid_from, valid_to,
            delegated_by_role_id, rbac_id ?? group_id, created_at ?? now, updated_at ?? now,
            created_by ?? Guid.Empty, updated_by ?? Guid.Empty);
    }
}

public sealed record RoleUpdateRequest(
    Guid id,
    Guid role_type_id,
    bool is_deputy,
    DateTimeOffset valid_from,
    DateTimeOffset? valid_to = null,
    DateTimeOffset? updated_at = null,
    Guid? updated_by = null
) : IUpdateDTOModel<RoleModel>
{
    public static RoleUpdateRequest FromModel(RoleModel model)
        => new(model.id, model.role_type_id, model.is_deputy, model.valid_from, model.valid_to, model.updated_at, model.updated_by);

    public RoleModel ApplyTo(RoleModel model) => model with
    {
        role_type_id = role_type_id,
        is_deputy = is_deputy,
        valid_from = valid_from,
        valid_to = valid_to,
        updated_at = updated_at ?? DateTimeOffset.UtcNow,
        updated_by = updated_by ?? model.updated_by
    };

    public RoleModel ToModel() => new(id, Guid.Empty, Guid.Empty, role_type_id, is_deputy, valid_from, valid_to,
        null, RbacWellKnown.RootSecurityObjectId, DateTimeOffset.UtcNow,
        updated_at ?? DateTimeOffset.UtcNow, Guid.Empty, updated_by ?? Guid.Empty);
}

public interface IRoleStore : IBaseStore<RoleModel> { }
