using WebAppArchitecture.DBLayer;
using WebAppArchitecture.Group.Models;
using WebAppArchitecture.Role.Models;

namespace WebAppArchitecture.SecurityLayer;

public sealed class SecurityProjectionService(IDBLayer db) : ISecurityProjectionService
{
    public async Task RebuildAllAsync(CancellationToken cancellationToken = default)
    {
        await db.DeleteWhereAsync<EffectiveAccessModel>(_ => true, cancellationToken);

        var roles = db.Query<RoleModel>().ToArray();
        var groups = db.Query<GroupModel>().Select(x => new { x.id, x.path }).ToArray();
        var rows = new List<EffectiveAccessModel>();
        foreach (var role in roles)
        {
            var marker = $"/{role.group_id:D}/";
            foreach (var target in groups.Where(g => g.path.Contains(marker, StringComparison.OrdinalIgnoreCase)))
                rows.Add(new EffectiveAccessModel(role.user_id, target.id, role.role_type_id, role.id, role.group_id, role.valid_from, role.valid_to));
        }

        if (rows.Count > 0)
            await db.CreateRangeAsync(rows, cancellationToken);
    }
}
