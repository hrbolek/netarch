using WebAppArchitecture.Base.Data;
using WebAppArchitecture.Base.Security;
using WebAppArchitecture.Base.Services;
using WebAppArchitecture.SecurityLayer;
using WebAppArchitecture.Group.Models;

namespace WebAppArchitecture.Group.Services;

public interface IGroupService : IBaseService<GroupModel, GroupResponse> { }

public sealed class GroupService : BaseService<GroupModel, GroupResponse>, IGroupService
{
    private readonly ISecurityProjectionService _projection;

    public GroupService(ISecurityLayer security, ISecurityProjectionService projection)
        : base(security) => _projection = projection;

    public override async Task<GroupResponse> CreateAsync<TCreateRequest>(TCreateRequest model, CancellationToken cancellationToken = default)
    {
        var result = await base.CreateAsync(model, cancellationToken);
        await _projection.RebuildAllAsync(cancellationToken);
        return result;
    }

    public override async Task<GroupResponse> UpdateAsync<TUpdateRequest>(TUpdateRequest model, CancellationToken cancellationToken = default)
    {
        var result = await base.UpdateAsync(model, cancellationToken);
        await _projection.RebuildAllAsync(cancellationToken);
        return result;
    }

    public override async Task DeleteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        await base.DeleteAsync(id, cancellationToken);
        await _projection.RebuildAllAsync(cancellationToken);
    }
}

public interface IGroupTypeService : IBaseService<GroupTypeModel, GroupTypeResponse> { }

public sealed class GroupTypeService : BaseService<GroupTypeModel, GroupTypeResponse>, IGroupTypeService
{
    public GroupTypeService(ISecurityLayer security) : base(security) { }
}
