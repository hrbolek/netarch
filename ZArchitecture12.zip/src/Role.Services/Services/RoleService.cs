using WebAppArchitecture.Base.Security;
using WebAppArchitecture.Base.Services;
using WebAppArchitecture.SecurityLayer;
using WebAppArchitecture.Role.Models;

namespace WebAppArchitecture.Role.Services;

public interface IRoleService : IBaseService<RoleModel, RoleResponse> { }

public sealed class RoleService : BaseService<RoleModel, RoleResponse>, IRoleService
{
    private readonly ISecurityProjectionService _projection;

    public RoleService(ISecurityLayer security, ISecurityProjectionService projection)
        : base(security) => _projection = projection;

    public override async Task<RoleResponse> CreateAsync<TCreateRequest>(TCreateRequest model, CancellationToken cancellationToken = default)
    {
        var result = await base.CreateAsync(model, cancellationToken);
        await _projection.RebuildAllAsync(cancellationToken);
        return result;
    }

    public override async Task<RoleResponse> UpdateAsync<TUpdateRequest>(TUpdateRequest model, CancellationToken cancellationToken = default)
    {
        var result = await base.UpdateAsync(model, cancellationToken);
        await _projection.RebuildAllAsync(cancellationToken);
        return result;
    }

    public override async Task DeleteAsync(Guid id, CancellationToken cancellationToken = default)
    {
        await base.DeleteAsync(id, cancellationToken);
        await _projection.RebuildAllAsync(cancellationToken);
    }
}
