using Microsoft.EntityFrameworkCore;
using WebAppArchitecture.Base.Security;
using WebAppArchitecture.Group.Models;
using WebAppArchitecture.Role.Models;
using WebAppArchitecture.RoleType.Models;
using WebAppArchitecture.User.Models;

namespace WebAppArchitecture.DBLayer;

public static class DatabaseInitializer
{
    public static async Task InitializeAsync(ApplicationDbContext db, CancellationToken cancellationToken = default)
    {
        await db.Database.EnsureCreatedAsync(cancellationToken);
        var now = DateTimeOffset.UtcNow;

        if (!await db.GroupTypes.AnyAsync(x => x.id == RbacWellKnown.RootGroupTypeId, cancellationToken))
        {
            db.GroupTypes.Add(new GroupTypeModel(
                RbacWellKnown.RootGroupTypeId, "Root group type", null,
                $"/{RbacWellKnown.RootGroupTypeId:D}/", RbacWellKnown.RootGroupId,
                now, now, RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
        }

        if (!await db.Groups.AnyAsync(x => x.id == RbacWellKnown.RootGroupId, cancellationToken))
        {
            db.Groups.Add(new GroupModel(
                RbacWellKnown.RootGroupId, "Root", RbacWellKnown.RootGroupTypeId, null,
                $"/{RbacWellKnown.RootGroupId:D}/", RbacWellKnown.RootGroupId,
                now, now, RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
        }

        foreach (var seed in FakeEntraSeedUsers.All.Append(new FakeEntraSeedUser(
                     RbacWellKnown.BootstrapAdminUserId, "Bootstrap Admin", "bootstrap@local", "Administrator")))
        {
            if (!await db.Users.AnyAsync(x => x.id == seed.id, cancellationToken))
            {
                db.Users.Add(new UserModel(seed.id, seed.Name, RbacWellKnown.RootGroupId, now, now,
                    RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
            }
        }

        var operationNames = new[]
        {
            RbacOperations.Create, RbacOperations.Read, RbacOperations.Update, RbacOperations.Delete,
            RbacOperations.List, RbacOperations.Vector, RbacOperations.ManageGroups,
            RbacOperations.ManageMemberships, RbacOperations.ManageRoles, RbacOperations.ManageSecurityObjects
        }.Select(x => x.Trim().ToLowerInvariant()).Distinct().ToArray();

        foreach (var operationName in operationNames)
        {
            if (!await db.Operations.AnyAsync(x => x.name == operationName, cancellationToken))
                db.Operations.Add(new OperationModel(Guid.NewGuid(), operationName, now, now,
                    RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
        }

        await db.SaveChangesAsync(cancellationToken);

        foreach (var roleName in new[] { "Administrator", "Rector", "Dean" })
        {
            var roleType = await db.RoleTypes.SingleOrDefaultAsync(x => x.name == roleName, cancellationToken);
            if (roleType is null)
            {
                roleType = new RoleTypeModel(Guid.NewGuid(), roleName, RbacWellKnown.RootGroupId,
                    now, now, RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId);
                db.RoleTypes.Add(roleType);
                await db.SaveChangesAsync(cancellationToken);
            }

            var operations = await db.Operations.Where(x => operationNames.Contains(x.name)).ToArrayAsync(cancellationToken);
            foreach (var operation in operations)
            {
                if (!await db.RoleTypeOperations.AnyAsync(x => x.role_type_id == roleType.id && x.operation_id == operation.id, cancellationToken))
                    db.RoleTypeOperations.Add(new RoleTypeOperationModel(Guid.NewGuid(), roleType.id, operation.id));
            }
        }

        await db.SaveChangesAsync(cancellationToken);

        foreach (var seed in FakeEntraSeedUsers.All.Append(new FakeEntraSeedUser(
                     RbacWellKnown.BootstrapAdminUserId, "Bootstrap Admin", "bootstrap@local", "Administrator")))
        {
            var roleType = await db.RoleTypes.SingleAsync(x => x.name == seed.RootRoleType, cancellationToken);
            if (!await db.Roles.AnyAsync(x => x.user_id == seed.id && x.group_id == RbacWellKnown.RootGroupId && x.role_type_id == roleType.id, cancellationToken))
            {
                db.Roles.Add(new RoleModel(Guid.NewGuid(), RbacWellKnown.RootGroupId, seed.id, roleType.id,
                    false, now.AddYears(-1), null, null, RbacWellKnown.RootGroupId, now, now,
                    RbacWellKnown.BootstrapAdminUserId, RbacWellKnown.BootstrapAdminUserId));
            }
        }

        await db.SaveChangesAsync(cancellationToken);
    }
}
