using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using WebAppArchitecture.Base.Data;

namespace WebAppArchitecture.DBLayer;

public sealed class DBLayer(ApplicationDbContext db, IServiceProvider services) : IDBLayer
{
    public IQueryable<TEntity> Query<TEntity>() where TEntity : class, IEntityDBModel
        => db.Set<TEntity>().AsNoTracking();

    private IBaseStore<TEntity>? Store<TEntity>() where TEntity : class, IEntityDBModel
        => services.GetService<IBaseStore<TEntity>>();

    public async Task<TEntity?> GetByIdAsync<TEntity>(Guid id, CancellationToken cancellationToken = default) where TEntity : class, IEntityDBModel
    {
        var store = Store<TEntity>();
        if (store is not null) return await store.GetByIdAsync(id, cancellationToken);
        return await db.Set<TEntity>().AsNoTracking().SingleOrDefaultAsync(x => x.id == id, cancellationToken);
    }

    public async Task<TEntity> CreateAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntityDBModel
    {
        var store = Store<TEntity>();
        if (store is not null) return await store.CreateAsync(entity, cancellationToken);
        db.Set<TEntity>().Add(entity);
        await db.SaveChangesAsync(cancellationToken);
        return entity;
    }

    public async Task<TEntity> UpdateAsync<TEntity>(TEntity entity, CancellationToken cancellationToken = default) where TEntity : class, IEntityDBModel
    {
        var store = Store<TEntity>();
        if (store is not null) return await store.UpdateAsync(entity, cancellationToken);
        db.Set<TEntity>().Update(entity);
        await db.SaveChangesAsync(cancellationToken);
        return entity;
    }

    public async Task DeleteAsync<TEntity>(Guid id, CancellationToken cancellationToken = default) where TEntity : class, IEntityDBModel
    {
        var store = Store<TEntity>();
        if (store is not null) { await store.DeleteAsync(id, cancellationToken); return; }
        var entity = await db.Set<TEntity>().SingleOrDefaultAsync(x => x.id == id, cancellationToken);
        if (entity is null) return;
        db.Set<TEntity>().Remove(entity);
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task CreateRangeAsync<TEntity>(IEnumerable<TEntity> entities, CancellationToken cancellationToken = default) where TEntity : class, IEntityDBModel
    {
        await db.Set<TEntity>().AddRangeAsync(entities, cancellationToken);
        await db.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteWhereAsync<TEntity>(Expression<Func<TEntity, bool>> predicate, CancellationToken cancellationToken = default) where TEntity : class, IEntityDBModel
    {
        var entities = await db.Set<TEntity>().Where(predicate).ToArrayAsync(cancellationToken);
        if (entities.Length == 0) return;
        db.Set<TEntity>().RemoveRange(entities);
        await db.SaveChangesAsync(cancellationToken);
    }
}
